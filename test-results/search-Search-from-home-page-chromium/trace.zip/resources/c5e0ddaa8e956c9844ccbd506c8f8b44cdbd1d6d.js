import {
  require_node
} from "/build/_shared/chunk-G7CHZRZX.js";
import {
  createHotContext
} from "/build/_shared/chunk-EHDP7SGR.js";
import {
  __commonJS,
  __toESM
} from "/build/_shared/chunk-PNG5AS42.js";

// empty-module:./auth.server
var require_auth = __commonJS({
  "empty-module:./auth.server"(exports, module) {
    module.exports = {};
  }
});

// empty-module:./db.server
var require_db = __commonJS({
  "empty-module:./db.server"(exports, module) {
    module.exports = {};
  }
});

// app/utils/permissions.ts
var import_node = __toESM(require_node(), 1);
var import_auth = __toESM(require_auth(), 1);
var import_db = __toESM(require_db(), 1);
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/utils/permissions.ts"
  );
  import.meta.hot.lastModified = "1706172714973.9167";
}
function parsePermissionString(permissionString) {
  const [action, entity, access] = permissionString.split(":");
  return {
    action,
    entity,
    access: access ? access.split(",") : void 0
  };
}
function userHasPermission(user, permission) {
  if (!user)
    return false;
  const { action, entity, access } = parsePermissionString(permission);
  return user.roles.some(
    (role) => role.permissions.some(
      (permission2) => permission2.entity === entity && permission2.action === action && (!access || access.includes(permission2.access))
    )
  );
}
function userHasRole(user, role) {
  if (!user)
    return false;
  return user.roles.some((r) => r.name === role);
}

export {
  userHasPermission,
  userHasRole
};
//# sourceMappingURL=/build/_shared/chunk-47KHF6VH.js.map
