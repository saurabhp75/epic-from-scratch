import {
  useRouteLoaderData
} from "/build/_shared/chunk-YK3DKXI3.js";
import {
  createHotContext
} from "/build/_shared/chunk-EHDP7SGR.js";

// app/utils/user.ts
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/utils/user.ts"
  );
  import.meta.hot.lastModified = "1706013736926.8281";
}
function useOptionalUser() {
  const data = useRouteLoaderData("root");
  return data?.user ?? null;
}
function useUser() {
  const maybeUser = useOptionalUser();
  if (!maybeUser) {
    throw new Error(
      "No user found in root loader, but user is required by useUser. If user is optional, try useOptionalUser instead."
    );
  }
  return maybeUser;
}

export {
  useOptionalUser,
  useUser
};
//# sourceMappingURL=/build/_shared/chunk-CBKDXE4E.js.map
