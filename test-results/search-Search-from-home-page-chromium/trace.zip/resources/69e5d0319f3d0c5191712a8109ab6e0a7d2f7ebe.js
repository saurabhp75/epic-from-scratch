import {
  __commonJS
} from "/build/_shared/chunk-PNG5AS42.js";

// empty-module:~/utils/db.server
var require_db = __commonJS({
  "empty-module:~/utils/db.server"(exports, module) {
    module.exports = {};
  }
});

export {
  require_db
};
//# sourceMappingURL=/build/_shared/chunk-KONDUBG3.js.map
