import {
  createHotContext
} from "/build/_shared/chunk-EHDP7SGR.js";
import "/build/_shared/chunk-UWV35TSL.js";
import "/build/_shared/chunk-PNG5AS42.js";

// app/utils/devtools.tsx
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/utils/devtools.tsx"
  );
  import.meta.hot.lastModified = "1704950618996.5151";
}
function init() {
  console.log("devtools initialized");
}
export {
  init
};
//# sourceMappingURL=/build/_shared/devtools-3TNO6EBL.js.map
